import { DatabaseSync } from 'node:sqlite';
import path from 'node:path';
import fs from 'node:fs';
import crypto from 'node:crypto';

// Ensure data directory exists
const DATA_DIR = path.resolve(process.cwd(), 'data');
if (!fs.existsSync(DATA_DIR)) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
}

const DB_PATH = path.join(DATA_DIR, 'techassist.db');
export const db = new DatabaseSync(DB_PATH);

// Enable WAL mode & foreign keys for high reliability
db.exec(`
  PRAGMA journal_mode = WAL;
  PRAGMA foreign_keys = ON;
`);

export function initDatabase() {
  db.exec(`
    CREATE TABLE IF NOT EXISTS users (
      id TEXT PRIMARY KEY,
      email TEXT UNIQUE NOT NULL,
      name TEXT NOT NULL,
      password_hash TEXT NOT NULL,
      role TEXT DEFAULT 'user',
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS sessions (
      token TEXT PRIMARY KEY,
      user_id TEXT NOT NULL,
      expires_at TEXT NOT NULL,
      FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS issues (
      id TEXT PRIMARY KEY,
      user_id TEXT NOT NULL,
      problem_text TEXT NOT NULL,
      category TEXT NOT NULL,
      matched_problem_id TEXT,
      confidence REAL DEFAULT 1.0,
      severity TEXT DEFAULT 'MEDIUM',
      status TEXT DEFAULT 'IN PROGRESS', -- 'OPEN', 'IN PROGRESS', 'RESOLVED', 'ESCALATED'
      resolution_summary TEXT,
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL,
      FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS conversations (
      id TEXT PRIMARY KEY,
      user_id TEXT NOT NULL,
      issue_id TEXT NOT NULL,
      title TEXT NOT NULL,
      status TEXT DEFAULT 'ACTIVE', -- 'ACTIVE', 'RESOLVED', 'ESCALATED'
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL,
      FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
      FOREIGN KEY (issue_id) REFERENCES issues(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS messages (
      id TEXT PRIMARY KEY,
      conversation_id TEXT NOT NULL,
      sender TEXT NOT NULL, -- 'user', 'agent', 'system'
      content TEXT NOT NULL,
      metadata_json TEXT,
      created_at TEXT NOT NULL,
      FOREIGN KEY (conversation_id) REFERENCES conversations(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS troubleshooting_steps (
      id TEXT PRIMARY KEY,
      issue_id TEXT NOT NULL,
      step_number INTEGER NOT NULL,
      node_id TEXT NOT NULL,
      question TEXT NOT NULL,
      instruction TEXT,
      user_response TEXT,
      outcome TEXT,
      created_at TEXT NOT NULL,
      FOREIGN KEY (issue_id) REFERENCES issues(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS tickets (
      id TEXT PRIMARY KEY, -- 'TS-2026-XXXXX'
      user_id TEXT NOT NULL,
      issue_id TEXT NOT NULL,
      problem_description TEXT NOT NULL,
      category TEXT NOT NULL,
      severity TEXT NOT NULL,
      priority TEXT NOT NULL, -- 'P1 - Critical', 'P2 - High', 'P3 - Normal', 'P4 - Low'
      status TEXT DEFAULT 'OPEN', -- 'OPEN', 'IN REVIEW', 'RESOLVED', 'CLOSED'
      escalation_reason TEXT NOT NULL,
      steps_attempted_json TEXT NOT NULL,
      created_at TEXT NOT NULL,
      FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
      FOREIGN KEY (issue_id) REFERENCES issues(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS knowledge_base (
      id TEXT PRIMARY KEY,
      problem_id TEXT UNIQUE NOT NULL,
      category TEXT NOT NULL,
      title TEXT NOT NULL,
      severity TEXT NOT NULL,
      symptoms_json TEXT NOT NULL,
      possible_causes_json TEXT NOT NULL,
      troubleshooting_tree_json TEXT NOT NULL,
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS feedback (
      id TEXT PRIMARY KEY,
      issue_id TEXT NOT NULL,
      user_id TEXT NOT NULL,
      rating INTEGER NOT NULL,
      comments TEXT,
      created_at TEXT NOT NULL,
      FOREIGN KEY (issue_id) REFERENCES issues(id) ON DELETE CASCADE,
      FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
    );
  `);

  // Seed default engineer/student account if users table is empty
  const userCount = db.prepare('SELECT count(*) as count FROM users').get() as { count: number };
  if (userCount.count === 0) {
    const salt = crypto.randomBytes(16).toString('hex');
    const hash = crypto.scryptSync('techassist2026', salt, 64).toString('hex');
    const passwordHash = `${salt}:${hash}`;
    const defaultUserId = 'user_student_demo';

    db.prepare(`
      INSERT INTO users (id, email, name, password_hash, role, created_at)
      VALUES (?, ?, ?, ?, ?, ?)
    `).run(
      defaultUserId,
      'student@techassist.ai',
      'CSE Engineer User',
      passwordHash,
      'engineer',
      new Date().toISOString()
    );
  }

  // Seed knowledge base from data/knowledge_base.json if empty
  const kbCount = db.prepare('SELECT count(*) as count FROM knowledge_base').get() as { count: number };
  if (kbCount.count === 0) {
    const kbFile = path.join(DATA_DIR, 'knowledge_base.json');
    if (fs.existsSync(kbFile)) {
      const raw = fs.readFileSync(kbFile, 'utf-8');
      const entries = JSON.parse(raw);
      const insertStmt = db.prepare(`
        INSERT INTO knowledge_base (id, problem_id, category, title, severity, symptoms_json, possible_causes_json, troubleshooting_tree_json, created_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
      `);

      for (const entry of entries) {
        insertStmt.run(
          `kb_${entry.problemId}`,
          entry.problemId,
          entry.category,
          entry.title,
          entry.severity || 'MEDIUM',
          JSON.stringify(entry.symptoms || []),
          JSON.stringify(entry.possibleCauses || []),
          JSON.stringify(entry.nodes || {}),
          new Date().toISOString()
        );
      }
    }
  }

  // Seed sample demonstration issues and tickets if empty
  const issueCount = db.prepare('SELECT count(*) as count FROM issues').get() as { count: number };
  if (issueCount.count === 0) {
    const now = new Date();
    const isoNow = now.toISOString();
    const demoUserId = 'user_student_demo';

    // 1. Resolved Issue: Wi-Fi Connected but No Internet Access
    const issue1Id = 'issue_demo_wifi_resolved';
    const conv1Id = 'conv_demo_wifi_resolved';
    db.prepare(`
      INSERT INTO issues (id, user_id, problem_text, category, matched_problem_id, confidence, severity, status, resolution_summary, created_at, updated_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).run(
      issue1Id,
      demoUserId,
      'My laptop is connected to Wi-Fi but websites will not load or open in browser.',
      'Network',
      'wifi-no-internet',
      0.95,
      'MEDIUM',
      'RESOLVED',
      'Local DNS resolver flushed with ipconfig /flushdns and winsock reset. Internet restored successfully.',
      new Date(now.getTime() - 3600000 * 2).toISOString(),
      new Date(now.getTime() - 3600000).toISOString()
    );

    db.prepare(`
      INSERT INTO conversations (id, user_id, issue_id, title, status, created_at, updated_at)
      VALUES (?, ?, ?, ?, ?, ?, ?)
    `).run(
      conv1Id,
      demoUserId,
      issue1Id,
      'Wi-Fi Connection & DNS Resolution Diagnosis',
      'RESOLVED',
      new Date(now.getTime() - 3600000 * 2).toISOString(),
      new Date(now.getTime() - 3600000).toISOString()
    );

    db.prepare(`
      INSERT INTO troubleshooting_steps (id, issue_id, step_number, node_id, question, instruction, user_response, outcome, created_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).run(
      'step_demo_1',
      issue1Id,
      1,
      'start',
      'Can another device connected to the same Wi-Fi access the internet?',
      'Test internet connectivity on a second device (phone or tablet).',
      'YES',
      'Continue diagnosis for local laptop DNS cache issue',
      new Date(now.getTime() - 3600000 * 2).toISOString()
    );

    db.prepare(`
      INSERT INTO troubleshooting_steps (id, issue_id, step_number, node_id, question, instruction, user_response, outcome, created_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).run(
      'step_demo_2',
      issue1Id,
      2,
      'check-dns-local',
      'After restarting your laptop, can you now load web pages?',
      'Flush DNS resolver and reset TCP/IP stack:\nipconfig /flushdns\nnetsh winsock reset',
      'YES',
      'Resolved: DNS resolver cache cleared and TCP stack reset',
      new Date(now.getTime() - 3600000).toISOString()
    );

    // 2. Escalated Issue: Laptop Overheating
    const issue2Id = 'issue_demo_overheating_escalated';
    const conv2Id = 'conv_demo_overheating_escalated';
    const ticketId = 'TS-2026-10492';

    db.prepare(`
      INSERT INTO issues (id, user_id, problem_text, category, matched_problem_id, confidence, severity, status, resolution_summary, created_at, updated_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).run(
      issue2Id,
      demoUserId,
      'Laptop chassis is extremely hot, thermal throttling and fan noise very loud.',
      'Hardware',
      'laptop-overheating',
      0.92,
      'HIGH',
      'ESCALATED',
      'Physical inspection confirmed vents are clear and surface is rigid; possible thermal paste degradation or failing fan bearing.',
      new Date(now.getTime() - 3600000 * 5).toISOString(),
      new Date(now.getTime() - 3600000 * 3).toISOString()
    );

    db.prepare(`
      INSERT INTO conversations (id, user_id, issue_id, title, status, created_at, updated_at)
      VALUES (?, ?, ?, ?, ?, ?, ?)
    `).run(
      conv2Id,
      demoUserId,
      issue2Id,
      'Laptop Thermal Throttling & Fan Noise Audit',
      'ESCALATED',
      new Date(now.getTime() - 3600000 * 5).toISOString(),
      new Date(now.getTime() - 3600000 * 3).toISOString()
    );

    db.prepare(`
      INSERT INTO tickets (id, user_id, issue_id, problem_description, category, severity, priority, status, escalation_reason, steps_attempted_json, created_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).run(
      ticketId,
      demoUserId,
      issue2Id,
      'Laptop chassis is extremely hot, thermal throttling and fan noise very loud.',
      'Hardware',
      'HIGH',
      'P2 - High',
      'OPEN',
      'Diagnostic steps completed: Laptop tested on hard desk surface, vents physically checked for dust obstructions. Hardware servicing required for thermal compound re-paste.',
      JSON.stringify([
        { stepNumber: 1, question: 'Is your laptop placed on a soft surface like a bed?', userResponse: 'HARD DESK' },
        { stepNumber: 2, question: 'Does Task Manager show any background process consuming over 50% CPU?', userResponse: 'NO' },
        { stepNumber: 3, question: 'Do you see visible dust clogging the bottom intake vents?', userResponse: 'NO' }
      ]),
      new Date(now.getTime() - 3600000 * 3).toISOString()
    );
  }
}
