import { db } from './database.ts';

export interface GeneratedTicket {
  ticketId: string;
  issueId: string;
  userId: string;
  problemDescription: string;
  category: string;
  severity: string;
  priority: string;
  status: string;
  escalationReason: string;
  stepsAttempted: Array<{
    step: number;
    question: string;
    instruction?: string;
    userResponse: string;
    outcome?: string;
  }>;
  createdAt: string;
}

export function generateSupportTicket(
  userId: string,
  issueId: string,
  customEscalationReason?: string
): GeneratedTicket {
  const issue = db.prepare('SELECT * FROM issues WHERE id = ?').get(issueId) as any;
  if (!issue) {
    throw new Error(`Issue not found: ${issueId}`);
  }

  // Generate random 5-digit number for ticket ID format TS-2026-XXXXX
  const randomNum = Math.floor(10000 + Math.random() * 90000);
  const ticketId = `TS-2026-${randomNum}`;

  // Severity to Priority mapping
  const severity = (issue.severity || 'HIGH').toUpperCase();
  let priority = 'P2 - High';
  if (severity === 'CRITICAL') priority = 'P1 - Critical';
  else if (severity === 'MEDIUM') priority = 'P3 - Normal';
  else if (severity === 'LOW') priority = 'P4 - Low';

  // Retrieve all attempted troubleshooting steps
  const stepsRows = db.prepare(`
    SELECT step_number, question, instruction, user_response, outcome
    FROM troubleshooting_steps
    WHERE issue_id = ?
    ORDER BY step_number ASC, created_at ASC
  `).all(issueId) as any[];

  const stepsAttempted = stepsRows.map((s, idx) => ({
    step: s.step_number || idx + 1,
    question: s.question,
    instruction: s.instruction,
    userResponse: s.user_response || 'Not answered',
    outcome: s.outcome || 'N/A'
  }));

  const escalationReason =
    customEscalationReason ||
    issue.resolution_summary ||
    'Interactive troubleshooting tree completed without resolution. Transferred to Tier 2 Technical Support Engineering.';

  const now = new Date().toISOString();

  // Save ticket to SQLite
  db.prepare(`
    INSERT INTO tickets (
      id, user_id, issue_id, problem_description, category, severity, priority, status, escalation_reason, steps_attempted_json, created_at
    ) VALUES (?, ?, ?, ?, ?, ?, ?, 'OPEN', ?, ?, ?)
  `).run(
    ticketId,
    userId,
    issueId,
    issue.problem_text,
    issue.category,
    severity,
    priority,
    escalationReason,
    JSON.stringify(stepsAttempted),
    now
  );

  // Update issue status to ESCALATED
  db.prepare(`
    UPDATE issues SET status = 'ESCALATED', resolution_summary = ?, updated_at = ? WHERE id = ?
  `).run(`Escalated as Support Ticket ${ticketId}: ${escalationReason}`, now, issueId);

  return {
    ticketId,
    issueId,
    userId,
    problemDescription: issue.problem_text,
    category: issue.category,
    severity,
    priority,
    status: 'OPEN',
    escalationReason,
    stepsAttempted,
    createdAt: now
  };
}
