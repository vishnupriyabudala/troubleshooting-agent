import { db } from './database.ts';
import fs from 'node:fs';
import path from 'node:path';

export interface DecisionOption {
  label: string;
  nextNodeId?: string;
  isResolution?: boolean;
  resolutionText?: string;
  isEscalation?: boolean;
  escalationReason?: string;
  summary?: string;
}

export interface DecisionNode {
  stepNumber: number;
  instruction: string;
  question: string;
  options: DecisionOption[];
}

export interface KBProblemEntry {
  problemId: string;
  category: string;
  title: string;
  severity: string;
  symptoms: string[];
  possibleCauses: string[];
  initialQuestion?: string;
  initialOptions?: string[];
  nodes: Record<string, DecisionNode>;
}

export function getAllKBEntries(): KBProblemEntry[] {
  try {
    const rows = db.prepare('SELECT * FROM knowledge_base ORDER BY category ASC').all() as any[];
    if (rows && rows.length > 0) {
      return rows.map((r) => ({
        problemId: r.problem_id,
        category: r.category,
        title: r.title,
        severity: r.severity,
        symptoms: JSON.parse(r.symptoms_json || '[]'),
        possibleCauses: JSON.parse(r.possible_causes_json || '[]'),
        nodes: JSON.parse(r.troubleshooting_tree_json || '{}')
      }));
    }
  } catch (err) {
    console.error('[KB] Error querying database, falling back to JSON:', err);
  }

  // Fallback to JSON file if DB query fails
  const jsonPath = path.resolve(process.cwd(), 'data', 'knowledge_base.json');
  if (fs.existsSync(jsonPath)) {
    const raw = fs.readFileSync(jsonPath, 'utf-8');
    return JSON.parse(raw);
  }
  return [];
}

export function getKBEntryById(problemId: string): KBProblemEntry | null {
  try {
    const row = db.prepare('SELECT * FROM knowledge_base WHERE problem_id = ?').get(problemId) as any;
    if (row) {
      return {
        problemId: row.problem_id,
        category: row.category,
        title: row.title,
        severity: row.severity,
        symptoms: JSON.parse(row.symptoms_json || '[]'),
        possibleCauses: JSON.parse(row.possible_causes_json || '[]'),
        nodes: JSON.parse(row.troubleshooting_tree_json || '{}')
      };
    }
  } catch (err) {
    console.error('[KB] Error fetching problem entry from DB:', err);
  }

  const entries = getAllKBEntries();
  return entries.find((e) => e.problemId === problemId) || null;
}
