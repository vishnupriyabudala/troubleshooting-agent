import express, { Request, Response } from 'express';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import dotenv from 'dotenv';
import { createServer as createViteServer } from 'vite';

import { initDatabase, db } from './backend/database.ts';
import { classifyProblem } from './backend/rule_classifier.ts';
import { getAllKBEntries, getKBEntryById } from './backend/knowledge_base.ts';
import { startDiagnosisSession, evaluateStepResponse } from './backend/decision_engine.ts';
import { generateSupportTicket } from './backend/ticket_generator.ts';
import { registerUser, loginUser, getUserByToken, logoutUser } from './backend/auth.ts';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Initialize DB schema & seed data
initDatabase();

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // Helper to extract authenticated user or fall back to demo engineer user
  function getRequestUser(req: Request) {
    const authHeader = req.headers.authorization;
    if (authHeader && authHeader.startsWith('Bearer ')) {
      const token = authHeader.substring(7);
      const user = getUserByToken(token);
      if (user) return user;
    }
    // Return standard demo user if not logged in
    const defaultUser = db.prepare('SELECT id, email, name, role, created_at FROM users LIMIT 1').get() as any;
    if (defaultUser) {
      return {
        id: defaultUser.id,
        email: defaultUser.email,
        name: defaultUser.name,
        role: defaultUser.role,
        createdAt: defaultUser.created_at
      };
    }
    return {
      id: 'user_student_demo',
      email: 'student@techassist.ai',
      name: 'CSE Engineer User',
      role: 'engineer',
      createdAt: new Date().toISOString()
    };
  }

  // -------------------------------------------------------------
  // AUTH ROUTES
  // -------------------------------------------------------------
  app.post('/api/auth/register', (req: Request, res: Response) => {
    try {
      const { email, name, password } = req.body;
      if (!email || !password || !name) {
        return res.status(400).json({ error: 'Name, email, and password are required.' });
      }
      const user = registerUser(email, name, password);
      const { token } = loginUser(email, password);
      return res.json({ user, token });
    } catch (err: any) {
      return res.status(400).json({ error: err.message || 'Registration failed.' });
    }
  });

  app.post('/api/auth/login', (req: Request, res: Response) => {
    try {
      const { email, password } = req.body;
      if (!email || !password) {
        return res.status(400).json({ error: 'Email and password are required.' });
      }
      const result = loginUser(email, password);
      return res.json(result);
    } catch (err: any) {
      return res.status(401).json({ error: err.message || 'Login failed.' });
    }
  });

  app.get('/api/auth/me', (req: Request, res: Response) => {
    const user = getRequestUser(req);
    return res.json({ user });
  });

  app.post('/api/auth/logout', (req: Request, res: Response) => {
    const authHeader = req.headers.authorization;
    if (authHeader && authHeader.startsWith('Bearer ')) {
      const token = authHeader.substring(7);
      logoutUser(token);
    }
    return res.json({ success: true });
  });

  // -------------------------------------------------------------
  // DIAGNOSIS & REASONING ROUTES
  // -------------------------------------------------------------
  app.post('/api/diagnose/classify', (req: Request, res: Response) => {
    try {
      const { problemText } = req.body;
      if (!problemText || typeof problemText !== 'string') {
        return res.status(400).json({ error: 'Problem description text is required.' });
      }
      const result = classifyProblem(problemText);
      return res.json(result);
    } catch (err: any) {
      return res.status(500).json({ error: err.message });
    }
  });

  app.post('/api/diagnose/start', (req: Request, res: Response) => {
    try {
      const { problemText, manualProblemId } = req.body;
      if (!problemText) {
        return res.status(400).json({ error: 'Problem description is required.' });
      }

      const user = getRequestUser(req);

      // Classify the problem using RuleClassifier
      const classification = classifyProblem(problemText);

      // Check if ambiguous or unknown
      if (classification.needsClarification && !manualProblemId) {
        return res.json({
          needsClarification: true,
          clarificationMessage: classification.clarificationMessage,
          confidence: classification.confidence,
          suggestedCategories: ['Network', 'Hardware', 'Performance', 'Browser', 'Printer', 'Software', 'Operating System', 'Storage']
        });
      }

      const problemId = manualProblemId || classification.problemId || 'wifi-no-internet';
      const category = classification.category === 'Ambiguous / Unknown' ? 'General' : classification.category;

      const session = startDiagnosisSession(
        user.id,
        problemText,
        problemId,
        category,
        classification.confidence
      );

      return res.json({
        needsClarification: false,
        classification,
        session
      });
    } catch (err: any) {
      console.error('[Diagnose Start Error]', err);
      return res.status(500).json({ error: 'Failed to start diagnostic session: ' + err.message });
    }
  });

  app.post('/api/diagnose/step', (req: Request, res: Response) => {
    try {
      const { issueId, conversationId, problemId, currentNodeId, response } = req.body;
      if (!issueId || !conversationId || !problemId || !currentNodeId || !response) {
        return res.status(400).json({ error: 'Missing required step parameters.' });
      }

      const stepResult = evaluateStepResponse(issueId, conversationId, problemId, currentNodeId, response);

      // If escalated, automatically generate ticket
      let generatedTicket = null;
      if (stepResult.isEscalated) {
        const user = getRequestUser(req);
        try {
          generatedTicket = generateSupportTicket(user.id, issueId, stepResult.escalationReason);
        } catch (e) {
          console.error('[Ticket Auto-Generation Error]', e);
        }
      }

      return res.json({
        ...stepResult,
        ticket: generatedTicket
      });
    } catch (err: any) {
      console.error('[Diagnose Step Error]', err);
      return res.status(500).json({ error: 'Failed to process step: ' + err.message });
    }
  });

  app.post('/api/diagnose/escalate', (req: Request, res: Response) => {
    try {
      const { issueId, customReason } = req.body;
      if (!issueId) {
        return res.status(400).json({ error: 'Issue ID is required.' });
      }
      const user = getRequestUser(req);
      const ticket = generateSupportTicket(user.id, issueId, customReason);
      return res.json({ success: true, ticket });
    } catch (err: any) {
      return res.status(500).json({ error: err.message });
    }
  });

  // -------------------------------------------------------------
  // ISSUES & CONVERSATIONS
  // -------------------------------------------------------------
  app.get('/api/issues', (req: Request, res: Response) => {
    try {
      const user = getRequestUser(req);
      const { status } = req.query;

      let query = 'SELECT * FROM issues WHERE user_id = ?';
      const params: any[] = [user.id];

      if (status && typeof status === 'string' && status !== 'ALL') {
        query += ' AND status = ?';
        params.push(status);
      }
      query += ' ORDER BY created_at DESC';

      const rows = db.prepare(query).all(...params) as any[];
      return res.json({ issues: rows });
    } catch (err: any) {
      return res.status(500).json({ error: err.message });
    }
  });

  app.get('/api/issues/:id', (req: Request, res: Response) => {
    try {
      const { id } = req.params;
      const issue = db.prepare('SELECT * FROM issues WHERE id = ?').get(id) as any;
      if (!issue) {
        return res.status(404).json({ error: 'Issue not found.' });
      }

      const steps = db.prepare(`
        SELECT * FROM troubleshooting_steps
        WHERE issue_id = ?
        ORDER BY step_number ASC, created_at ASC
      `).all(id);

      const conversation = db.prepare('SELECT * FROM conversations WHERE issue_id = ?').get(id);

      return res.json({ issue, steps, conversation });
    } catch (err: any) {
      return res.status(500).json({ error: err.message });
    }
  });

  app.get('/api/conversations', (req: Request, res: Response) => {
    try {
      const user = getRequestUser(req);
      const rows = db.prepare(`
        SELECT c.*, i.problem_text, i.category, i.status as issue_status, i.matched_problem_id
        FROM conversations c
        JOIN issues i ON c.issue_id = i.id
        WHERE c.user_id = ?
        ORDER BY c.updated_at DESC
      `).all(user.id);
      return res.json({ conversations: rows });
    } catch (err: any) {
      return res.status(500).json({ error: err.message });
    }
  });

  app.get('/api/conversations/:id/messages', (req: Request, res: Response) => {
    try {
      const { id } = req.params;
      const conversation = db.prepare('SELECT * FROM conversations WHERE id = ?').get(id) as any;
      if (!conversation) {
        return res.status(404).json({ error: 'Conversation not found.' });
      }

      const messages = db.prepare('SELECT * FROM messages WHERE conversation_id = ? ORDER BY created_at ASC').all(id);
      const issue = db.prepare('SELECT * FROM issues WHERE id = ?').get(conversation.issue_id);

      return res.json({ conversation, issue, messages });
    } catch (err: any) {
      return res.status(500).json({ error: err.message });
    }
  });

  // -------------------------------------------------------------
  // SUPPORT TICKETS
  // -------------------------------------------------------------
  app.get('/api/tickets', (req: Request, res: Response) => {
    try {
      const user = getRequestUser(req);
      const rows = db.prepare(`
        SELECT * FROM tickets
        WHERE user_id = ?
        ORDER BY created_at DESC
      `).all(user.id) as any[];

      const tickets = rows.map((r) => ({
        ...r,
        steps_attempted: JSON.parse(r.steps_attempted_json || '[]')
      }));

      return res.json({ tickets });
    } catch (err: any) {
      return res.status(500).json({ error: err.message });
    }
  });

  app.get('/api/tickets/:id', (req: Request, res: Response) => {
    try {
      const { id } = req.params;
      const row = db.prepare('SELECT * FROM tickets WHERE id = ?').get(id) as any;
      if (!row) {
        return res.status(404).json({ error: 'Ticket not found.' });
      }
      return res.json({
        ticket: {
          ...row,
          steps_attempted: JSON.parse(row.steps_attempted_json || '[]')
        }
      });
    } catch (err: any) {
      return res.status(500).json({ error: err.message });
    }
  });

  app.patch('/api/tickets/:id', (req: Request, res: Response) => {
    try {
      const { id } = req.params;
      const { status } = req.body;
      if (!status) return res.status(400).json({ error: 'Status is required' });
      db.prepare('UPDATE tickets SET status = ? WHERE id = ?').run(status, id);
      return res.json({ success: true, id, status });
    } catch (err: any) {
      return res.status(500).json({ error: err.message });
    }
  });

  app.delete('/api/issues/:id', (req: Request, res: Response) => {
    try {
      const { id } = req.params;
      db.prepare('DELETE FROM issues WHERE id = ?').run(id);
      return res.json({ success: true });
    } catch (err: any) {
      return res.status(500).json({ error: err.message });
    }
  });

  app.patch('/api/issues/:id', (req: Request, res: Response) => {
    try {
      const { id } = req.params;
      const { status, resolution_summary } = req.body;
      const now = new Date().toISOString();
      if (status && resolution_summary) {
        db.prepare('UPDATE issues SET status = ?, resolution_summary = ?, updated_at = ? WHERE id = ?').run(status, resolution_summary, now, id);
      } else if (status) {
        db.prepare('UPDATE issues SET status = ?, updated_at = ? WHERE id = ?').run(status, now, id);
      }
      return res.json({ success: true });
    } catch (err: any) {
      return res.status(500).json({ error: err.message });
    }
  });

  // -------------------------------------------------------------
  // KNOWLEDGE BASE
  // -------------------------------------------------------------
  app.get('/api/knowledge-base', (req: Request, res: Response) => {
    try {
      const entries = getAllKBEntries();
      return res.json({ entries });
    } catch (err: any) {
      return res.status(500).json({ error: err.message });
    }
  });

  app.post('/api/knowledge-base', (req: Request, res: Response) => {
    try {
      const { problemId, category, title, severity, symptoms, possibleCauses, nodes } = req.body;
      if (!problemId || !category || !title || !nodes) {
        return res.status(400).json({ error: 'Problem ID, category, title, and diagnostic nodes are required.' });
      }
      const now = new Date().toISOString();
      db.prepare(`
        INSERT INTO knowledge_base (id, problem_id, category, title, severity, symptoms_json, possible_causes_json, troubleshooting_tree_json, created_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        ON CONFLICT(problem_id) DO UPDATE SET
          category = excluded.category,
          title = excluded.title,
          severity = excluded.severity,
          symptoms_json = excluded.symptoms_json,
          possible_causes_json = excluded.possible_causes_json,
          troubleshooting_tree_json = excluded.troubleshooting_tree_json
      `).run(
        `kb_${problemId}`,
        problemId,
        category,
        title,
        severity || 'MEDIUM',
        JSON.stringify(symptoms || []),
        JSON.stringify(possibleCauses || []),
        JSON.stringify(nodes || {}),
        now
      );
      return res.json({ success: true, problemId });
    } catch (err: any) {
      return res.status(500).json({ error: err.message });
    }
  });

  app.get('/api/knowledge-base/:id', (req: Request, res: Response) => {
    try {
      const entry = getKBEntryById(req.params.id);
      if (!entry) {
        return res.status(404).json({ error: 'Knowledge base entry not found.' });
      }
      return res.json({ entry });
    } catch (err: any) {
      return res.status(500).json({ error: err.message });
    }
  });

  // -------------------------------------------------------------
  // REAL DASHBOARD STATS
  // -------------------------------------------------------------
  app.get('/api/dashboard/stats', (req: Request, res: Response) => {
    try {
      const user = getRequestUser(req);

      const activeIssues = db.prepare("SELECT count(*) as count FROM issues WHERE user_id = ? AND status IN ('OPEN', 'IN PROGRESS')").get(user.id) as { count: number };
      const resolvedIssues = db.prepare("SELECT count(*) as count FROM issues WHERE user_id = ? AND status = 'RESOLVED'").get(user.id) as { count: number };
      const escalatedIssues = db.prepare("SELECT count(*) as count FROM issues WHERE user_id = ? AND status = 'ESCALATED'").get(user.id) as { count: number };
      const openTickets = db.prepare("SELECT count(*) as count FROM tickets WHERE user_id = ? AND status = 'OPEN'").get(user.id) as { count: number };

      const recentConversations = db.prepare(`
        SELECT c.id, c.title, c.status, c.created_at, i.category, i.severity
        FROM conversations c
        JOIN issues i ON c.issue_id = i.id
        WHERE c.user_id = ?
        ORDER BY c.created_at DESC
        LIMIT 5
      `).all(user.id);

      const categoryDistribution = db.prepare(`
        SELECT category, count(*) as count
        FROM issues
        WHERE user_id = ?
        GROUP BY category
        ORDER BY count DESC
      `).all(user.id);

      return res.json({
        activeIssues: activeIssues.count,
        resolvedIssues: resolvedIssues.count,
        escalatedIssues: escalatedIssues.count,
        openTickets: openTickets.count,
        recentConversations,
        categoryDistribution
      });
    } catch (err: any) {
      return res.status(500).json({ error: err.message });
    }
  });

  // -------------------------------------------------------------
  // FEEDBACK
  // -------------------------------------------------------------
  app.post('/api/feedback', (req: Request, res: Response) => {
    try {
      const { issueId, rating, comments } = req.body;
      if (!issueId || rating === undefined) {
        return res.status(400).json({ error: 'Issue ID and rating are required.' });
      }
      const user = getRequestUser(req);
      db.prepare(`
        INSERT INTO feedback (id, issue_id, user_id, rating, comments, created_at)
        VALUES (?, ?, ?, ?, ?, ?)
      `).run(
        `fb_${Date.now()}`,
        issueId,
        user.id,
        rating,
        comments || '',
        new Date().toISOString()
      );
      return res.json({ success: true });
    } catch (err: any) {
      return res.status(500).json({ error: err.message });
    }
  });

  // -------------------------------------------------------------
  // VITE MIDDLEWARE (Development) or STATIC (Production)
  // -------------------------------------------------------------
  if (process.env.NODE_ENV === 'production') {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (_req, res) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  } else {
    const vite = await createViteServer({
      server: { middlewareMode: true, hmr: process.env.DISABLE_HMR !== 'true' },
      appType: 'spa'
    });
    app.use(vite.middlewares);
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`[TechAssist AI] Server listening on http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('[TechAssist AI Server Fatal Error]', err);
  process.exit(1);
});
