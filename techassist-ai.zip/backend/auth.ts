import crypto from 'node:crypto';
import { db } from './database.ts';

export interface User {
  id: string;
  email: string;
  name: string;
  role: string;
  createdAt: string;
}

export function hashPassword(password: string): string {
  const salt = crypto.randomBytes(16).toString('hex');
  const hash = crypto.scryptSync(password, salt, 64).toString('hex');
  return `${salt}:${hash}`;
}

export function verifyPassword(password: string, storedHash: string): boolean {
  const [salt, key] = storedHash.split(':');
  if (!salt || !key) return false;
  const derivedKey = crypto.scryptSync(password, salt, 64).toString('hex');
  return crypto.timingSafeEqual(Buffer.from(key, 'hex'), Buffer.from(derivedKey, 'hex'));
}

export function registerUser(email: string, name: string, password: string): User {
  const existing = db.prepare('SELECT id FROM users WHERE email = ?').get(email.toLowerCase().trim());
  if (existing) {
    throw new Error('An account with this email address already exists.');
  }

  const userId = `usr_${crypto.randomUUID().slice(0, 8)}`;
  const passwordHash = hashPassword(password);
  const now = new Date().toISOString();

  db.prepare(`
    INSERT INTO users (id, email, name, password_hash, role, created_at)
    VALUES (?, ?, ?, ?, 'user', ?)
  `).run(userId, email.toLowerCase().trim(), name.trim(), passwordHash, now);

  return {
    id: userId,
    email: email.toLowerCase().trim(),
    name: name.trim(),
    role: 'user',
    createdAt: now
  };
}

export function loginUser(email: string, password: string): { user: User; token: string } {
  const user = db.prepare('SELECT * FROM users WHERE email = ?').get(email.toLowerCase().trim()) as any;
  if (!user) {
    throw new Error('Invalid email or password.');
  }

  const isMatch = verifyPassword(password, user.password_hash);
  if (!isMatch) {
    throw new Error('Invalid email or password.');
  }

  // Generate token and record session
  const token = `tok_${crypto.randomUUID()}`;
  const expiresAt = new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString(); // 30 days

  db.prepare(`
    INSERT INTO sessions (token, user_id, expires_at)
    VALUES (?, ?, ?)
  `).run(token, user.id, expiresAt);

  return {
    user: {
      id: user.id,
      email: user.email,
      name: user.name,
      role: user.role,
      createdAt: user.created_at
    },
    token
  };
}

export function getUserByToken(token: string): User | null {
  if (!token) return null;
  const session = db.prepare(`
    SELECT s.token, s.expires_at, u.id, u.email, u.name, u.role, u.created_at
    FROM sessions s
    JOIN users u ON s.user_id = u.id
    WHERE s.token = ?
  `).get(token) as any;

  if (!session) return null;

  // Check expiration
  if (new Date(session.expires_at).getTime() < Date.now()) {
    db.prepare('DELETE FROM sessions WHERE token = ?').run(token);
    return null;
  }

  return {
    id: session.id,
    email: session.email,
    name: session.name,
    role: session.role,
    createdAt: session.created_at
  };
}

export function logoutUser(token: string): void {
  if (token) {
    db.prepare('DELETE FROM sessions WHERE token = ?').run(token);
  }
}
