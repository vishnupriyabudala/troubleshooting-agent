import { getKBEntryById, KBProblemEntry, DecisionOption } from './knowledge_base.ts';
import { db } from './database.ts';
import crypto from 'node:crypto';

export interface StartDiagnosisSessionResult {
  isValid: boolean;
  error?: string;
  issueId: string;
  conversationId: string;
  problemId: string;
  category: string;
  title: string;
  severity: string;
  symptoms: string[];
  possibleCauses: string[];
  currentNodeId: string;
  stepNumber: number;
  instruction: string;
  question: string;
  options: string[];
  optionsDetails: DecisionOption[];
  status: string;
}

export interface StepEvaluationResult {
  isValid: boolean;
  error?: string;
  status: 'IN PROGRESS' | 'RESOLVED' | 'ESCALATED';
  isComplete: boolean;
  isEscalated: boolean;
  currentNodeId?: string;
  stepNumber?: number;
  instruction?: string;
  question?: string;
  options?: string[];
  optionsDetails?: DecisionOption[];
  resolutionText?: string;
  escalationReason?: string;
  summary?: string;
}

export function startDiagnosisSession(
  userId: string,
  problemText: string,
  problemId: string,
  category: string,
  confidence: number
): StartDiagnosisSessionResult {
  const entry = getKBEntryById(problemId);
  if (!entry) {
    return {
      isValid: false,
      error: `Knowledge base template for '${problemId}' not found.`,
      issueId: '',
      conversationId: '',
      problemId,
      category,
      title: '',
      severity: 'MEDIUM',
      symptoms: [],
      possibleCauses: [],
      currentNodeId: '',
      stepNumber: 0,
      instruction: '',
      question: '',
      options: [],
      optionsDetails: [],
      status: 'OPEN'
    };
  }

  const startNode = entry.nodes?.start;
  if (!startNode) {
    return {
      isValid: false,
      error: 'Malformed troubleshooting tree: missing start node.',
      issueId: '',
      conversationId: '',
      problemId,
      category,
      title: entry.title,
      severity: entry.severity,
      symptoms: entry.symptoms,
      possibleCauses: entry.possibleCauses,
      currentNodeId: '',
      stepNumber: 0,
      instruction: '',
      question: '',
      options: [],
      optionsDetails: [],
      status: 'OPEN'
    };
  }

  const issueId = `issue_${crypto.randomUUID().slice(0, 8)}`;
  const conversationId = `conv_${crypto.randomUUID().slice(0, 8)}`;
  const now = new Date().toISOString();

  // 1. Create Issue record
  db.prepare(`
    INSERT INTO issues (id, user_id, problem_text, category, matched_problem_id, confidence, severity, status, created_at, updated_at)
    VALUES (?, ?, ?, ?, ?, ?, ?, 'IN PROGRESS', ?, ?)
  `).run(issueId, userId, problemText, category, problemId, confidence, entry.severity, now, now);

  // 2. Create Conversation record
  db.prepare(`
    INSERT INTO conversations (id, user_id, issue_id, title, status, created_at, updated_at)
    VALUES (?, ?, ?, ?, 'ACTIVE', ?, ?)
  `).run(conversationId, userId, issueId, `${entry.title} Diagnosis`, now, now);

  // 3. Add initial user message
  db.prepare(`
    INSERT INTO messages (id, conversation_id, sender, content, metadata_json, created_at)
    VALUES (?, ?, 'user', ?, ?, ?)
  `).run(`msg_${crypto.randomUUID().slice(0, 8)}`, conversationId, problemText, JSON.stringify({ category, confidence }), now);

  // 4. Add initial agent response with first diagnostic question
  const agentInitialContent = `I have classified your problem as **${category}**: *${entry.title}*.\n\n` +
    `**Possible Causes:**\n` + entry.possibleCauses.map((c) => `• ${c}`).join('\n') + `\n\n` +
    `Let's troubleshoot step-by-step.\n\n` +
    `**Step 1:** ${startNode.instruction}\n\n` +
    `**Question:** ${startNode.question}`;

  db.prepare(`
    INSERT INTO messages (id, conversation_id, sender, content, metadata_json, created_at)
    VALUES (?, ?, 'agent', ?, ?, ?)
  `).run(
    `msg_${crypto.randomUUID().slice(0, 8)}`,
    conversationId,
    agentInitialContent,
    JSON.stringify({
      nodeId: 'start',
      stepNumber: 1,
      options: startNode.options.map((o) => o.label)
    }),
    now
  );

  return {
    isValid: true,
    issueId,
    conversationId,
    problemId,
    category: entry.category,
    title: entry.title,
    severity: entry.severity,
    symptoms: entry.symptoms,
    possibleCauses: entry.possibleCauses,
    currentNodeId: 'start',
    stepNumber: startNode.stepNumber || 1,
    instruction: startNode.instruction,
    question: startNode.question,
    options: startNode.options.map((o) => o.label),
    optionsDetails: startNode.options,
    status: 'IN PROGRESS'
  };
}

export function evaluateStepResponse(
  issueId: string,
  conversationId: string,
  problemId: string,
  currentNodeId: string,
  userResponse: string
): StepEvaluationResult {
  const entry = getKBEntryById(problemId);
  if (!entry) {
    return { isValid: false, error: 'Knowledge base entry not found.', status: 'IN PROGRESS', isComplete: false, isEscalated: false };
  }

  const nodes = entry.nodes || {};
  const currentNode = nodes[currentNodeId];
  if (!currentNode) {
    return { isValid: false, error: `Invalid step node: ${currentNodeId}`, status: 'IN PROGRESS', isComplete: false, isEscalated: false };
  }

  const respNorm = userResponse.trim().toUpperCase();

  // Find matching option
  let matchedOpt: DecisionOption | undefined = currentNode.options.find(
    (opt) => opt.label.toUpperCase() === respNorm || respNorm.includes(opt.label.toUpperCase())
  );

  if (!matchedOpt) {
    if (respNorm.includes('YES')) {
      matchedOpt = currentNode.options.find((o) => o.label.toUpperCase().includes('YES'));
    } else if (respNorm.includes('NO')) {
      matchedOpt = currentNode.options.find((o) => o.label.toUpperCase().includes('NO'));
    }
  }

  if (!matchedOpt) {
    return {
      isValid: false,
      error: `Please choose one of the available choices: ${currentNode.options.map((o) => o.label).join(', ')}`,
      status: 'IN PROGRESS',
      isComplete: false,
      isEscalated: false
    };
  }

  const now = new Date().toISOString();

  // 1. Record the user message in conversation
  db.prepare(`
    INSERT INTO messages (id, conversation_id, sender, content, metadata_json, created_at)
    VALUES (?, ?, 'user', ?, ?, ?)
  `).run(`msg_${crypto.randomUUID().slice(0, 8)}`, conversationId, userResponse, JSON.stringify({ chosenOption: matchedOpt.label }), now);

  // 2. Record the troubleshooting step in database
  db.prepare(`
    INSERT INTO troubleshooting_steps (id, issue_id, step_number, node_id, question, instruction, user_response, outcome, created_at)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
  `).run(
    `step_${crypto.randomUUID().slice(0, 8)}`,
    issueId,
    currentNode.stepNumber || 1,
    currentNodeId,
    currentNode.question,
    currentNode.instruction,
    userResponse,
    matchedOpt.summary || (matchedOpt.isResolution ? 'Resolved' : matchedOpt.isEscalation ? 'Escalated' : 'Advanced to next step'),
    now
  );

  // 3. Handle Resolution
  if (matchedOpt.isResolution) {
    const resolutionText = matchedOpt.resolutionText || 'Issue resolved successfully.';

    db.prepare(`
      UPDATE issues SET status = 'RESOLVED', resolution_summary = ?, updated_at = ? WHERE id = ?
    `).run(resolutionText, now, issueId);

    db.prepare(`
      UPDATE conversations SET status = 'RESOLVED', updated_at = ? WHERE id = ?
    `).run(now, conversationId);

    const agentMsg = `🎉 **Issue Resolved!**\n\n${resolutionText}\n\nThank you for using TechAssist AI. Your troubleshooting session has been archived in My Issues.`;
    db.prepare(`
      INSERT INTO messages (id, conversation_id, sender, content, metadata_json, created_at)
      VALUES (?, ?, 'agent', ?, ?, ?)
    `).run(`msg_${crypto.randomUUID().slice(0, 8)}`, conversationId, agentMsg, JSON.stringify({ isResolution: true }), now);

    return {
      isValid: true,
      status: 'RESOLVED',
      isComplete: true,
      isEscalated: false,
      resolutionText,
      summary: matchedOpt.summary
    };
  }

  // 4. Handle Escalation
  if (matchedOpt.isEscalation) {
    const escalationReason = matchedOpt.escalationReason || 'Automated troubleshooting steps did not resolve the problem.';

    db.prepare(`
      UPDATE issues SET status = 'ESCALATED', resolution_summary = ?, updated_at = ? WHERE id = ?
    `).run(`Escalated: ${escalationReason}`, now, issueId);

    db.prepare(`
      UPDATE conversations SET status = 'ESCALATED', updated_at = ? WHERE id = ?
    `).run(now, conversationId);

    return {
      isValid: true,
      status: 'ESCALATED',
      isComplete: true,
      isEscalated: true,
      escalationReason,
      summary: matchedOpt.summary
    };
  }

  // 5. Advance to next node
  const nextNodeId = matchedOpt.nextNodeId;
  if (!nextNodeId || !nodes[nextNodeId]) {
    // Reached leaf node without resolution -> Escalate
    const reason = 'End of automated troubleshooting tree reached without complete resolution.';
    db.prepare(`
      UPDATE issues SET status = 'ESCALATED', resolution_summary = ?, updated_at = ? WHERE id = ?
    `).run(`Escalated: ${reason}`, now, issueId);

    return {
      isValid: true,
      status: 'ESCALATED',
      isComplete: true,
      isEscalated: true,
      escalationReason: reason
    };
  }

  const nextNode = nodes[nextNodeId];
  const agentMsg = `**Step ${nextNode.stepNumber}:** ${nextNode.instruction}\n\n**Question:** ${nextNode.question}`;

  db.prepare(`
    INSERT INTO messages (id, conversation_id, sender, content, metadata_json, created_at)
    VALUES (?, ?, 'agent', ?, ?, ?)
  `).run(
    `msg_${crypto.randomUUID().slice(0, 8)}`,
    conversationId,
    agentMsg,
    JSON.stringify({
      nodeId: nextNodeId,
      stepNumber: nextNode.stepNumber,
      options: nextNode.options.map((o) => o.label)
    }),
    now
  );

  return {
    isValid: true,
    status: 'IN PROGRESS',
    isComplete: false,
    isEscalated: false,
    currentNodeId: nextNodeId,
    stepNumber: nextNode.stepNumber,
    instruction: nextNode.instruction,
    question: nextNode.question,
    options: nextNode.options.map((o) => o.label),
    optionsDetails: nextNode.options,
    summary: matchedOpt.summary
  };
}
